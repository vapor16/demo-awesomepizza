package com.adesso.project.awesomepizza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwesomepizzaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwesomepizzaApplication.class, args);
	}

}
